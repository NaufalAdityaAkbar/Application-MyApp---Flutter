import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ChatDetailPage extends StatefulWidget {
  final String contactName;
  final String contactPhoneNumber;
  final String loggedInPhoneNumber;

  ChatDetailPage({
    required this.contactName,
    required this.contactPhoneNumber,
    required this.loggedInPhoneNumber,
  });

  @override
  _ChatDetailPageState createState() => _ChatDetailPageState();
}

class _ChatDetailPageState extends State<ChatDetailPage> {
  final TextEditingController _controller = TextEditingController();
  List<dynamic> messages = [];

@override
void initState() {
    super.initState();
    fetchMessages();
    Timer.periodic(Duration(seconds: 2), (timer) {
      if (mounted) fetchMessages();
    });
}

  // Fungsi untuk mengambil pesan dari backend
Future<void> fetchMessages() async {
    try {
      final response = await http.get(
        Uri.parse(
            'http://<YOUR-IP-ADDRESS>:3000/api/chats/messages/${widget.loggedInPhoneNumber}/${widget.contactPhoneNumber}'),
      );

      if (response.statusCode == 200) {
        setState(() {
          messages = json.decode(response.body)['messages'];
        });
      } else {
        print("Error fetching messages: ${response.statusCode}");
      }
    } catch (e) {
      print("Exception fetching messages: $e");
    }
}

  // Fungsi untuk mengirim pesan
  Future<void> sendMessage(String message) async {
    if (message.trim().isEmpty) return;

    setState(() {
      messages.add({
        'message': message,
        'sender_phone': widget.loggedInPhoneNumber,
      });
    });
    _controller.clear();

    final response = await http.post(
      Uri.parse('http://localhost:3000/api/chats/send'),
      body: jsonEncode({
        'sender_phone': widget.loggedInPhoneNumber,
        'receiver_phone': widget.contactPhoneNumber,
        'message': message,
      }),
      headers: {"Content-Type": "application/json"},
    );

    if (response.statusCode != 201) {
      print("Error sending message: ${response.statusCode} - ${response.body}");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.contactName),
        backgroundColor: Colors.black,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: messages.length,
              itemBuilder: (context, index) {
                var message = messages[index];
                return Align(
                  alignment:
                      message['sender_phone'] == widget.loggedInPhoneNumber
                          ? Alignment.centerRight
                          : Alignment.centerLeft,
                  child: Container(
                    margin: EdgeInsets.all(8.0),
                    padding: EdgeInsets.all(10.0),
                    decoration: BoxDecoration(
                      color:
                          message['sender_phone'] == widget.loggedInPhoneNumber
                              ? Colors.blue
                              : Colors.grey,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      message['message'],
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(hintText: "Type a message"),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send, color: Colors.blue),
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      sendMessage(_controller.text);
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ),
      backgroundColor: Colors.black,
    );
  }
}
