import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  final String phoneNumber;

  const HomeScreen({Key? key, required this.phoneNumber}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Contacts'),
            Tab(text: 'Status'),
            Tab(text: 'Call'),
            Tab(text: 'Community'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          ContactsTab(),
          Center(child: Text('Status Page')),
          Center(child: Text('Call Page')),
          Center(child: Text('Community Page')),
        ],
      ),
    );
  }
}
