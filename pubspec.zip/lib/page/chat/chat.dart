import 'package:flutter/material.dart';

class ChatListScreen extends StatelessWidget {
  const ChatListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, String>> chats = [
      {"name": "Alice", "message": "Hello, how are you?"},
      {"name": "Bob", "message": "Let's meet tomorrow!"},
      {"name": "Charlie", "message": "Check this out!"},
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Chats')),
      body: ListView.builder(
        itemCount: chats.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(chats[index]["name"]!),
            subtitle: Text(chats[index]["message"]!),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChatDetailScreen(name: chats[index]["name"]!),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
