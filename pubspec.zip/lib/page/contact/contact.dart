import 'package:flutter/material.dart';

class ContactsTab extends StatelessWidget {
  final List<Map<String, String>> contacts = [
    {"name": "Alice", "phone_number": "+1234567890"},
    {"name": "Bob", "phone_number": "+0987654321"},
    {"name": "Charlie", "phone_number": "+1122334455"},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: contacts.length,
      itemBuilder: (context, index) {
        return ListTile(
          leading: CircleAvatar(
            child: Text(contacts[index]["name"]![0]),
          ),
          title: Text(contacts[index]["name"]!),
          subtitle: Text(contacts[index]["phone_number"]!),
          trailing: IconButton(
            icon: Icon(Icons.chat),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ChatScreen(name: contacts[index]["name"]!),
                ),
              );
            },
          ),
        );
      },
    );
  }
}
