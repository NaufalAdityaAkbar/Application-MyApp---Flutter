import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'dart:convert';
import 'dart:io';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController bioController = TextEditingController();
  File? _image; // For storing the selected image

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().getImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _uploadProfile() async {
    if (_image == null || nameController.text.isEmpty || bioController.text.isEmpty) {
      // Handle validation errors
      print('Please fill all fields and select an image.');
      return;
    }

    final request = http.MultipartRequest(
      'POST',
      Uri.parse('http://10.0.2.2:3000/users/profile'),
    );
    
    request.fields['phone_number'] = 'your_phone_number'; // Replace with actual phone number
    request.fields['name'] = nameController.text;
    request.fields['bio'] = bioController.text;
    request.files.add(await http.MultipartFile.fromPath('photo', _image!.path));

    final response = await request.send();
    
    if (response.statusCode == 201) {
      print('Profile updated successfully!');
      // Handle success (navigate to menu or show a message)
    } else {
      print('Failed to upload profile: ${response.reasonPhrase}');
      // Handle error
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Complete Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: CircleAvatar(
                radius: 50,
                backgroundImage: _image == null ? null : FileImage(_image!),
                child: _image == null ? const Icon(Icons.camera_alt, size: 50) : null,
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: bioController,
              decoration: const InputDecoration(labelText: 'Bio'),
            ),
            ElevatedButton(
              onPressed: _uploadProfile,
              child: const Text('Upload Profile'),
            ),
          ],
        ),
      ),
    );
  }
}
